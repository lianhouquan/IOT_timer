#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 
#define USART_REC_LEN  			50  	//�����������ֽ��� 50
extern u8 flag_u1date_rec_fin,cnt_u1date_rec_fin,UASART2_REC_CNT;
extern u8 flag_which_usart;
extern u8 u1_date[USART_REC_LEN];
extern u8 flag_u2date_rec_fin,cnt_u2date_rec_fin;
extern u8 u2_date[USART_REC_LEN];
void uart_init(u32 bound);
void ESP_UART2_init(u32 bound);
void U2sendChar(u8 ch);
void U2send(u8* date,u8 len);
#endif


