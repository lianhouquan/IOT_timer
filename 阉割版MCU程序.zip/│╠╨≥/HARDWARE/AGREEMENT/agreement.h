#ifndef __AGREEMENT_H
#define __AGREEMENT_H

#include "sys.h"
#include "usart.h"
#include "rtc.h"
#include "flash.h"
void agreement_process(u8 date[],u8 date_len,u8 which_com);

#endif
