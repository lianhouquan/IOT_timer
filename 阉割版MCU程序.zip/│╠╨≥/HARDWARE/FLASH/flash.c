#include "flash.h"
u8 initaldate[16]={19,7,23,12,0,0};
u8 SSID[WIFI_LEN]="",PSW[WIFI_LEN]="";
void FLASH_WriteByte(u32 addr , u8 *p , u16 Byte_Num)
{	
	u32 HalfWord;
	Byte_Num = Byte_Num/2;
	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	FLASH_ErasePage(addr);
	while(Byte_Num --)
	{
		HalfWord=*(p++);
		HalfWord|=*(p++)<<8;
		FLASH_ProgramHalfWord(addr, HalfWord);
		addr += 2;
	}
	FLASH_Lock();
}
void FLASH_ReadByte(uint32_t addr , uint8_t *p , uint16_t Byte_Num)
{
	 while(Byte_Num--)
		{
		*(p++)=*((uint8_t*)addr++);
		}
}

void write_date(u8 *write_buff)
{
	u8 *p_date;//����ָ��
	u32 HalfWord,addr=WRITE_START_ADDR;
	u16 Byte_Num = 0;

	FLASH_Unlock();
	FLASH_ClearFlag(FLASH_FLAG_BSY | FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
	FLASH_ErasePage(WRITE_START_ADDR);
	Byte_Num=(ALARM_DATE_SIZE_BYTE-(2*WIFI_LEN))/2;
	p_date=write_buff;
	while(Byte_Num --)
	{
		HalfWord=*(p_date++);
		HalfWord|=*(p_date++)<<8;
		FLASH_ProgramHalfWord(addr, HalfWord);
		addr += 2;
	}//д��alarmdate
	Byte_Num=WIFI_LEN/2;
	p_date=SSID;
	while(Byte_Num --)
	{
		HalfWord=*(p_date++);
		HalfWord|=*(p_date++)<<8;
		FLASH_ProgramHalfWord(addr, HalfWord);
		addr += 2;
	}//д��WIFI��ssid
	Byte_Num=WIFI_LEN/2;
	p_date=PSW;
	while(Byte_Num --)
	{
		HalfWord=*(p_date++);
		HalfWord|=*(p_date++)<<8;
		FLASH_ProgramHalfWord(addr, HalfWord);
		addr += 2;
	}//д��WIFI��password
	FLASH_Lock();
	
	
}

void read_date(u8 *read_buff)
{
	FLASH_ReadByte(WRITE_START_ADDR,read_buff ,ALARM_DATE_SIZE_BYTE-(2*WIFI_LEN));
	FLASH_ReadByte(WRITE_START_ADDR+ALARM_DATE_SIZE_BYTE-(2*WIFI_LEN),SSID ,WIFI_LEN);
	FLASH_ReadByte(WRITE_START_ADDR+ALARM_DATE_SIZE_BYTE-WIFI_LEN,PSW ,WIFI_LEN);
}

