#include "action.h"
//���±�������ָʾ��Դ״̬
u8 flag_power_220v=0;
u8 flag_220v_mode=0;//0��ʾ�Զ�ģʽ��1��ʾ�ֶ�����2��ʾ�ֶ���
u8 flag_power_esp826=0;
u8 alarm_date[ALARM_NUMB][6];
extern u8 show_flag;
void POWER_220V(u8 enable)
{
	if(enable){SW_PW=1;flag_power_220v=1;}
	else{SW_PW=0;flag_power_220v=0;}
}
void POWER_ESP8266(u8 enable)
{
	if(enable){SW_ESP=1;flag_power_esp826=1;}
	else{SW_ESP=0;flag_power_esp826=0;}
}

//��ʱ����ת����һ�����֣�����ʱ���ж�
u32 time2num(u8 hour,u8 minute,u8 second)
{
	return (hour*3600)+(minute*60)+second;
}
//������ʱ�������������ڵ�ʱ�򣬾ʹ򿪺͹ر�220V��Դ
void POWER_220V_PROCESS(u8 hour_now,u8 minute_now,u8 second_now,u8 alarm_date[][6])
{
	u8 act=0,i=0;
	u32 time_now,time_min,time_max;
	time_now=time2num(hour_now,minute_now,second_now);
	for(i=0;i<ALARM_NUMB;i++)
	{
		time_min=time2num(alarm_date[i][0],alarm_date[i][1],alarm_date[i][2]);
		time_max=time2num(alarm_date[i][3],alarm_date[i][4],alarm_date[i][5]);
		if((time_now>=time_min)&&(time_now<=time_max))act=1;
	}
	POWER_220V(act);
}

void Alarm_set(u8 num,u8 hour_on,u8 minute_on,u8 second_on,u8 hour_off,u8 minute_off,u8 second_off)
{
	if(num<ALARM_NUMB)
	{	
		if(time2num(hour_on,minute_on,second_on)<time2num(hour_off,minute_off,second_off))
		{
			alarm_date[num][0]=hour_on;
			alarm_date[num][1]=minute_on;
			alarm_date[num][2]=second_on;
			alarm_date[num][3]=hour_off;
			alarm_date[num][4]=minute_off;
			alarm_date[num][5]=second_off;
			write_date((u8 *)alarm_date);
			printf("ok\r\n");show_flag=1;
		}
		else {printf("error\r\n");show_flag=2;}
	}
	else {printf("error\r\n");show_flag=2;}
}
//[1]:220V(1) or ESP(0)  [2] ESP:On(1)/Off(0)  220V:�Զ�(0)/�ֶ���(1)/�ֶ���(0)
void power_control(u8 which,u8 enable)
{
	if(which==0){SW_PW=enable;}
	else if(which==1){flag_220v_mode=enable;}
	printf("ok\r\n");show_flag=1;
}

void processWIFI_date(u8 *date)
{
	u8 i=0;
	u8 ssid_len=date[1];
	u8 psw_len=date[date[1]+2];
	SSID[0]=ssid_len;
	PSW[0]=psw_len;
	for(i=0;i<WIFI_LEN-1;i++)
	{
		if(i<ssid_len)SSID[i+1]=date[i+2];
		else SSID[i+1]=0xFF;
	}
	SSID[ssid_len+1]='E';SSID[ssid_len+2]='F';SSID[0]+=2;//�����β
	for(i=0;i<WIFI_LEN-1;i++)
	{
		if(i<psw_len)PSW[i+1]=date[ssid_len+3+i];
		else PSW[i+1]=0xFF;
	}
	PSW[psw_len+1]='E';PSW[psw_len+2]='F';PSW[0]+=2;//�����β
	write_date((u8 *)alarm_date);//д������
	flag_need_reConnect=1;
}
