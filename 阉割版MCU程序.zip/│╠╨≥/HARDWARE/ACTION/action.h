#ifndef __ACTION_H
#define __ACTION_H

#include "sys.h"
#include "led.h"
#include "flash.h"
#include "usart.h"
extern u8 flag_power_220v,flag_power_esp826,flag_220v_mode;
extern u8 alarm_date[ALARM_NUMB][6];
void POWER_220V(u8 enable);
void POWER_ESP8266(u8 enable);
void POWER_220V_PROCESS(u8 hour_now,u8 minute_now,u8 second_now,u8 alarm_date[][6]);
void Alarm_set(u8 num,u8 hour_on,u8 minute_on,u8 second_on,u8 hour_off,u8 minute_off,u8 second_off);
void power_control(u8 which,u8 enable);
void processWIFI_date(u8 *date);
#endif
