#include "led.h"
#include "delay.h"
#include "sys.h"
#include "exti.h"
#include "oled.h"
#include "usart.h"	  
#include "rtc.h" 		
#include "flash.h"
#include "agreement.h"
#include "action.h"
#define TIME_DELAY 3
extern	u8 Res;
s32 theID=56;
//show_flag��ʾ��ʾ�����ݣ����(0).�ɹ�(1).ʧ��(2)
u8 show_flag=0;
void show_time(void);
//���嶨ʱ�������ݵ����顣����ÿ��6�����ݣ�ǰ3���ǿ���ʱ�䣬��3���ǹر�ʱ��
int main(void)
{	
	u32 i;
	u8 show_t_sec;
	delay_init();	    	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	
	LED_Init();		
	EXTIX_Init();
	uart_init(9600);
	//ESP_UART2_init(115200);
	RTC_Init();
	OLED_Init();			//��ʼ��OLED  
	OLED_Clear(); 
	read_date((u8 *)alarm_date);
	//init_ESP8266();
  while(1)
	{
		if(show_t_sec!=calendar.sec)
		{
			LED1=0;
			//ÿ��ʱ����µĲ�����
			show_t_sec=calendar.sec;
			show_time();
			if(!flag_220v_mode)POWER_220V_PROCESS(calendar.hour,calendar.min,calendar.sec,alarm_date);
			else if(flag_220v_mode==1) POWER_220V(1);
			else if(flag_220v_mode==2) POWER_220V(0);
			LED1=1;
			i++;//if(i%5==1)GetWifiInformation();if(i%5==2)stndIDtoServer(theID);
			//if(flag_need_reConnect){flag_need_reConnect=0;SW_ESP=0;delay_ms(10);init_ESP8266();}
		}
		if(flag_u1date_rec_fin){LED2=0;agreement_process(u1_date,cnt_u1date_rec_fin,1);LED2=1;}//����1�յ�����
		//if(flag_u2date_rec_fin){LED2=0;agreement_process(u2_date,cnt_u2date_rec_fin,2);LED2=1;}//����2�յ�����
		
	}
}
void show_time(void)
{
	static u8 time_delay_cnt=3;
	if(show_flag)time_delay_cnt=3;
	if(time_delay_cnt)
	{
		OLED_Display_On();
			if(show_flag)
		{
			if(show_flag==1)
			{
				OLED_ShowCHinese(0,4,4);
				OLED_ShowCHinese(16,4,5);
			}
			else if(show_flag==2)
			{
				OLED_ShowCHinese(0,4,2);
				OLED_ShowCHinese(16,4,3);
			}
			show_flag=0;
		}
		else
		{
			OLED_ShowString(0,4,"    ");
		}
		OLED_ShowChar(0,6,'T');
		OLED_ShowChar(8,6,'C');
		OLED_ShowChar(16,6,'P');
//		if(flag_wifiConnect)
//		{
//			OLED_ShowCHinese(24,6,9);//��
//			OLED_ShowCHinese(40,6,6);//��
//			OLED_ShowCHinese(56,6,7);//��
//		}
//		else
//		{
//			OLED_ShowCHinese(24,6,8);//δ
//			OLED_ShowCHinese(40,6,6);//��
//			OLED_ShowCHinese(56,6,7);//��
//		}
		
		OLED_ShowCHinese(0,0,0);
		OLED_ShowCHinese(16,0,1);
		OLED_ShowChar1(0,32,':');
		OLED_ShowNum(40,0,calendar.w_year,4,16);
		OLED_ShowChar(72,0,'-');
		OLED_ShowNum(80,0,calendar.w_month,2,16);
		OLED_ShowChar(96,0,'-');		
		OLED_ShowNum(104,0,calendar.w_date,2,16);
		
		OLED_ShowNum(40,2,calendar.hour,2,16);
		OLED_ShowChar(56,2,':');
		OLED_ShowNum(64,2,calendar.min,2,16);
		OLED_ShowChar(80,2,':');
		OLED_ShowNum(88,2,calendar.sec,2,16);
	}
	else 
	{
		OLED_Display_Off();
	}
	if(time_delay_cnt>0)time_delay_cnt--;
}
