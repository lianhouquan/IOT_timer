#include <Winsock2.h>
#include <stdio.h>

WORD    wVer;
WSADATA wsa;
SOCKET  sockClient;
SOCKADDR_IN addrSrv;

void client_init(void)
{
	printf("Client is Starting...\n");
    wVer = MAKEWORD( 1, 1 );
	WSAStartup( wVer, &wsa );
    sockClient=socket(AF_INET,SOCK_STREAM,0);
    addrSrv.sin_addr.S_un.S_addr=inet_addr("127.0.0.1");
    

	addrSrv.sin_family=AF_INET;
	addrSrv.sin_port=htons(5050);
    
	
}

void client_run(void)
{
	char sendBuf[100],recvBuf[100];

   
	connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR));
	while(1)
	{
		printf("Input a message to server:");
		gets(sendBuf);
		send(sockClient,sendBuf,strlen(sendBuf)+1,0);
		recv(sockClient,recvBuf,100,0);
		printf(" Receive a message from server:");
		puts(recvBuf);
	}
}

void client_quit(void)
{
  	closesocket(sockClient);
	WSACleanup();
}

void main()
{
	

    client_init();
   	client_run();
	client_quit();
	

}
