package com.timer;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Build;
import android.os.Looper;
import android.os.Message;
import android.os.Bundle;
import android.text.InputType;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.annotation.RequiresApi;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;
import java.util.regex.Pattern;

import static java.util.concurrent.TimeUnit.MILLISECONDS;


public class MainActivity extends Activity {

    public final static int MESSAGE_DATA = 0x01;
    static String IP_initial="lhqiot.top";
    UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    public static final String TAG = "MainActivity";
    private BroadcastReceiver mRceiver;
    private TCPClient tcpClient;
    static final Semaphore semp = new Semaphore(1);

    public static Context context ;
    private Button buttonSerch;
    private Button buttonAbout;
    private Button buttonSendAlarm;
    private Button buttonSetTime;
    private Button buttonGetTimeAndAlarm;
    private Button buttonGetTimeSwESP;
    private Button buttonGetTimeSw220VPW;
    private Button buttonGetTimeSetWIFI;
    private Button buttonGetTimeBtExit;
    private Button buttonTCPConnect;
    private Button buttonTCPSend;
    private Button buttonTCPClosed;
    private TimePicker timePicker1;
    private TimePicker timePicker2;
    private TimePicker timePicker1Net;
    private TimePicker timePicker2Net;
    private Button buttonSendAlarmNet;
    private Button buttonSetTimeNet;
    private Button buttonGetTimeAndAlarmNet;
    private Button buttonGetTimeSw220VPWNET;
    private EditText editTextNumberNet;
    private EditText editTextNumber;
    private EditText editTextIP;
    private EditText editTextPort;
    private EditText editTextTCPID;
    private TextView textViewTcpRec;
    private ListView listViewInformation;
    private ListView listViewDevices;
    private ArrayList<String> arrayList;
    private ArrayAdapter<String> arrayAdapter;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice bluetoothDevice=null;
    private BluetoothSocket bluetoothSocket=null;
    private OutputStream outputStream=null;
    private InputStream inputStream=null;

    private final String NAME = "Bluetooth_Socket";
    ExecutorService exec = Executors.newCachedThreadPool();
    //接收来自其他线程的消息并处理
    private MyHandler myHandler = new MyHandler();

    //服务端线程任务
    AcceptThread acceptThread;

    public MainActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(MainActivity.TAG, "on Creat");
        context=this;
        getPermission();
        //获得本地蓝牙适配器
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        initView();

        //检查是否支持蓝牙
        checkBluetoothSupport();
        Toast.makeText(MainActivity.this, "开始搜索蓝牙设备,首次搜索时间较长,请耐心等待...", Toast.LENGTH_SHORT).show();

        //搜索附近蓝牙设备
        serchBluetoothDevice();

        //设置广播接收器
        mRceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(action)){
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
//                    arrayAdapter.add(device.getName()+ ":" + device.getAddress());
                    String dev = device.getName()+":"+device.getAddress();
                    if (!arrayList.contains(dev)){
                        arrayList.add(dev);
                    }
                    arrayAdapter.notifyDataSetChanged(); //通知ListView适配器 数据已经发生改变
                }else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)){
                    Log.d(TAG,"搜索结束!");

                    //在主线程中显示搜索结束信息
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "搜索结束!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }else if(action.equals("tcpClientReceiver")){
                    String msg = intent.getStringExtra("tcpClientReceiver");
                    Message message = Message.obtain();
                    message.what = 2;
                    message.obj = msg;
                    myHandler.sendMessage(message);
                    //接收到TCP发来的消息
                }
            }
        };
        //注册广播
        IntentFilter intentFilter = new IntentFilter("tcpClientReceiver");
        intentFilter.addAction(BluetoothDevice.ACTION_FOUND);
        intentFilter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        registerReceiver(mRceiver, intentFilter);

        //启动接收线程任务
        acceptThread = new AcceptThread();
        acceptThread.start();
    }

    /**
     * 搜索蓝牙设备
     * startDiscovery方法是异步的
     */
    private void serchBluetoothDevice() {
        //搜索设备
        while (!bluetoothAdapter.startDiscovery()){
            Log.d(TAG, "尝试失败");
            try {
                Thread.sleep(100);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
    }

    /**
     * 检测是否支持蓝牙
     */
    private void checkBluetoothSupport() {
        //检测是否支持蓝牙
        if (bluetoothAdapter!=null) {
            //打开蓝牙
            if (!bluetoothAdapter.isEnabled()) {
//                对话框提示
//                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                //静默打开
                bluetoothAdapter.enable();
                bluetoothAdapter.cancelDiscovery();
            }
        }else{
            finish();
        }
    }

    /**
     * 初始化布局控件功能
     */
    private void initView() {
        int i;
        for(i=0;i< semp.availablePermits();i++){
            try {
                semp.acquire();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        buttonAbout = (Button)findViewById(R.id.button_about);
        buttonAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "本软件适配时控开关1.01版本--------制作人by LHQ...", Toast.LENGTH_LONG).show();
            }
        });

        //搜索蓝牙设备,搜索之前断开当前连接,并清空存储蓝牙设备的arrayList
        buttonSerch = (Button)findViewById(R.id.button_serch);
        buttonSerch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrayList.clear();
                if (bluetoothSocket != null)
                    try {
                        if (bluetoothSocket.isConnected())
                            bluetoothSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                if (bluetoothAdapter.isDiscovering()) {
                    bluetoothAdapter.cancelDiscovery();
                }

                Toast.makeText(MainActivity.this, "开始搜索蓝牙设备...", Toast.LENGTH_LONG).show();
                serchBluetoothDevice();
            }
        });

        //设置ListView点击事件监听,点击item连接相应的蓝牙设备
        listViewDevices = (ListView)findViewById(R.id.listView_devices);
        arrayList = new ArrayList<>();
//        getPairingBluetoothDevice();
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        listViewDevices.setAdapter(arrayAdapter);
        listViewDevices.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String devices = arrayAdapter.getItem(i);
                String address = devices.substring(devices.indexOf(":") + 1).trim();

                Toast.makeText(MainActivity.this, "正在蓝牙连接,请稍等...", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "address -->  " + address);

                /**
                 * 连接与断开开启新线程原因:  如果不开新线程,程序在close的时候会闪退
                 */
                //连接新的设备时,断开当前连接
                if (bluetoothSocket != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "in  disconnect Thread ");
                            if (bluetoothSocket.isConnected()) {
                                try {
                                    bluetoothSocket.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }// end of if
                        }
                    }).start();
                }

                //连接新设备
                bluetoothDevice = bluetoothAdapter.getRemoteDevice(address);
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Log.d(TAG, "in  connect Thread ");
                            //获得设备
                            bluetoothSocket = bluetoothDevice.createRfcommSocketToServiceRecord(uuid);
                            bluetoothSocket.connect();
                            outputStream = bluetoothSocket.getOutputStream();
                            inputStream = bluetoothSocket.getInputStream();

                            //在主线程中显示连接成功提示信息
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (bluetoothSocket.isConnected()) {

                                        arrayList.clear();
                                        arrayAdapter.notifyDataSetChanged();
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(MainActivity.this, "已连接!", Toast.LENGTH_SHORT).show();
                                                setContentView(R.layout.bluetooth_layout);
                                                initViewBT();
                                            }
                                        });
                                    }
                                    Log.d(MainActivity.TAG, "已连接!");
                                }
                            });
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });

        editTextIP=(EditText)findViewById(R.id.editText_IP);
        editTextPort=(EditText)findViewById(R.id.editText_Port);
        buttonTCPConnect=(Button)findViewById(R.id.button_netConnect);
        buttonTCPConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String IPs=getIP(editTextIP.getText().toString());
                if(isIpValid(IPs)){
                    tcpClient = new TCPClient(IPs,getPort(editTextPort.getText().toString()));//建立连接
                    Toast.makeText(MainActivity.this, "正在TCP连接,请稍等...", Toast.LENGTH_SHORT).show();
                    exec.execute(tcpClient);
                    try {
                        if(semp.tryAcquire(500,MILLISECONDS)){
                            setContentView(R.layout.internet_layout);
                            initViewTCP();
                        }else {
                            tcpClient.closeSelf();
                            Toast.makeText(MainActivity.this, "连接超时", Toast.LENGTH_SHORT).show();
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }else  Toast.makeText(MainActivity.this, "请输入正确的IP地址", Toast.LENGTH_SHORT).show();
            }
        });

    }

    /**
     * 蓝牙连接后，第二界面的布局
     * 主要实现三个按钮的功能
     */
    private void initViewBT(){
        /////////////////////////////////////////////////////////////
        timePicker1=(TimePicker) findViewById(R.id.tPicker1);
        timePicker2=(TimePicker) findViewById(R.id.tPicker2);
        timePicker1.setIs24HourView(true);
        timePicker2.setIs24HourView(true);
        editTextNumber=(EditText)findViewById(R.id.editText_which);

        listViewInformation=(ListView)findViewById(R.id.listView_information);
        arrayList = new ArrayList<>();
//        getPairingBluetoothDevice();
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        listViewInformation.setAdapter(arrayAdapter);

        buttonSendAlarm=(Button) findViewById(R.id.button_sendAlarm);
        buttonSendAlarm.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if((timePicker2.getHour()*60+timePicker2.getMinute())>(timePicker1.getHour()*60+timePicker1.getMinute())) {
                    if((editTextNumber.length()==1) && (Integer.parseInt(editTextNumber.getText().toString())<=8)) {
                        byte dateAlarm[] = new byte[10];
                        dateAlarm[0] = 'A';
                        dateAlarm[1] = (byte) Integer.parseInt(editTextNumber.getText().toString());
                        dateAlarm[2] = (byte) timePicker1.getHour();
                        dateAlarm[3] = (byte) timePicker1.getMinute();
                        dateAlarm[4] = (byte) 0x00;
                        dateAlarm[5] = (byte) timePicker2.getHour();
                        dateAlarm[6] = (byte) timePicker2.getMinute();
                        dateAlarm[7] = (byte) 0x00;
                        dateAlarm[8] = 'E';
                        dateAlarm[9] = 'F';
                        if (outputStream != null) {
                            try {
                                outputStream.write(dateAlarm);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    else
                        Toast.makeText(MainActivity.this, "当前未连接任何设备!", Toast.LENGTH_SHORT).show();
                    }
                    else Toast.makeText(MainActivity.this, "请输入正确的时间段序号!", Toast.LENGTH_SHORT).show();
                }
                else Toast.makeText(MainActivity.this, "开启时间必须早于关闭时间!", Toast.LENGTH_SHORT).show();
            }
        });//该按钮用于实现闹钟设置
        buttonSetTime=(Button)findViewById(R.id.button_setTime);
        buttonSetTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                byte dateTime[]=new byte[9];
                dateTime[0] = 'S';
                //获取系统的日期
                Calendar calendar = Calendar.getInstance();
                dateTime[1] = (byte)(calendar.get(Calendar.YEAR)-2000);//年
                dateTime[2] = (byte)(calendar.get(Calendar.MONTH)+1);//月
                dateTime[3] = (byte)calendar.get(Calendar.DAY_OF_MONTH);//日
                dateTime[4] = (byte)calendar.get(Calendar.HOUR_OF_DAY);//小时
                dateTime[5] = (byte)calendar.get(Calendar.MINUTE);//分钟
                dateTime[6] = (byte)calendar.get(Calendar.SECOND);//秒
                dateTime[7] = 'E';
                dateTime[8] = 'F';
                if (outputStream != null) {
                    try {
                        outputStream.write(dateTime);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }else
                    Toast.makeText(MainActivity.this, "当前未连接任何设备!", Toast.LENGTH_SHORT).show();

            }
        });//该按钮用于设置设备的时间
        buttonGetTimeAndAlarm=(Button)findViewById(R.id.button_getTimeAndAlarm);
        buttonGetTimeAndAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                byte getDate[]=new byte[3];
                getDate[0]='T';getDate[1]='E';getDate[2]='F';
                if (outputStream != null) {
                    try {
                        outputStream.write(getDate);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }else
                    Toast.makeText(MainActivity.this, "当前未连接任何设备!", Toast.LENGTH_SHORT).show();
                arrayAdapter.clear();
            }
        });//该按钮用于获取整个设备的时间等信息
        ///////////////////////////////////////////////////////////

        buttonGetTimeSwESP=(Button)findViewById(R.id.button_SW_ESP);
        buttonGetTimeSwESP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "功能未实现，敬请期待!", Toast.LENGTH_SHORT).show();
            }
        });
        buttonGetTimeSw220VPW=(Button)findViewById(R.id.button_SW_PW);
        buttonGetTimeSw220VPW.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SetSWInformaation(1);
            }
        });
        buttonGetTimeSetWIFI=(Button)findViewById(R.id.button_SetWIFI);
        buttonGetTimeSetWIFI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SetWiFiInformaation();
            }
        });
        buttonGetTimeBtExit=(Button)findViewById(R.id.button_BT_Exit);
        buttonGetTimeBtExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (bluetoothSocket != null) {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "in  disconnect Thread ");
                            if (bluetoothSocket.isConnected()) {
                                try {
                                    bluetoothSocket.close();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }// end of if
                        }
                    }).start();
                }
                setContentView(R.layout.activity_main);
                initView();
            }
        });
    }


    /**
     * TCP连接后，第三界面的布局
     * 主要实现三个按钮的功能
     */
    private void initViewTCP(){
        editTextTCPID=(EditText)findViewById(R.id.editTextTcpSend);
        textViewTcpRec=(TextView)findViewById(R.id.textViewTcpRec);
        textViewTcpRec.setTextColor(android.graphics.Color.RED);
        timePicker1Net=(TimePicker)findViewById(R.id.tPicker1NET);
        timePicker2Net=(TimePicker)findViewById(R.id.tPicker2NET);
        timePicker1Net.setIs24HourView(true);
        timePicker2Net.setIs24HourView(true);
        editTextNumberNet=(EditText)findViewById(R.id.editText_whichNET);
        buttonTCPSend=(Button)findViewById(R.id.buttonTcpSend);
        buttonTCPSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exec.execute(new Runnable() {
                    @Override
                    public void run() {
                        if(!editTextTCPID.getText().toString().equals("")){
                            int ID=Integer.valueOf(editTextTCPID.getText().toString());
                            if(ID!=0) {
                                byte[] date=new byte[7];
                                date[0]='J';date[5]='E';date[6]='F';
                                for (int i = 1; i < 5; i++) {
                                    date[i] = (byte) (ID>>8*(4-i));
                                }
                                try {
                                    if(tcpClient.IsLinked()){
                                        tcpClient.send(date);
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            else{ Looper.prepare();Toast.makeText(MainActivity.this, "请输入非0的ID!", Toast.LENGTH_SHORT).show();Looper.loop();}
                        }
                        else { Looper.prepare();Toast.makeText(MainActivity.this, "请输入ID!", Toast.LENGTH_SHORT).show();Looper.loop();}

                    }
                });
            }
        });

        buttonTCPClosed=(Button)findViewById(R.id.buttonTcpClosed);
        buttonTCPClosed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tcpClient.closeSelf();
                setContentView(R.layout.activity_main);
                initView();
            }
        });

        buttonSendAlarmNet=(Button)findViewById(R.id.button_sendAlarmNET);
        buttonSendAlarmNet.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                exec.execute(new Runnable() {
                    @Override
                    public void run() {
                        if((timePicker2Net.getHour()*60+timePicker2Net.getMinute())>(timePicker1Net.getHour()*60+timePicker1Net.getMinute())) {
                            if((editTextNumberNet.length()==1) && (Integer.parseInt(editTextNumberNet.getText().toString())<=8)) {
                                byte dateAlarm[] = new byte[10];
                                dateAlarm[0] = 'A';
                                dateAlarm[1] = (byte) Integer.parseInt(editTextNumberNet.getText().toString());
                                dateAlarm[2] = (byte) timePicker1Net.getHour();
                                dateAlarm[3] = (byte) timePicker1Net.getMinute();
                                dateAlarm[4] = (byte) 0x00;
                                dateAlarm[5] = (byte) timePicker2Net.getHour();
                                dateAlarm[6] = (byte) timePicker2Net.getMinute();
                                dateAlarm[7] = (byte) 0x00;
                                dateAlarm[8] = 'E';
                                dateAlarm[9] = 'F';
                                try {
                                    if(tcpClient.IsLinked()){
                                        tcpClient.send(dateAlarm);
                                    }
                                    else { Looper.prepare();Toast.makeText(MainActivity.this, "TCP服务未连接!", Toast.LENGTH_SHORT).show();Looper.loop();}
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                            else {Looper.prepare();Toast.makeText(MainActivity.this, "请输入正确的时间段序号!", Toast.LENGTH_SHORT).show();Looper.loop();}
                        }
                        else {Looper.prepare();Toast.makeText(MainActivity.this, "开启时间必须早于关闭时间!", Toast.LENGTH_SHORT).show();Looper.loop();}
                    }
                });
            }

        });

        buttonSetTimeNet=(Button)findViewById(R.id.button_setTimeNET);
        buttonSetTimeNet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exec.execute(new Runnable() {
                    @Override
                    public void run() {
                        byte dateTime[]=new byte[9];
                        dateTime[0] = 'S';
                        //获取系统的日期
                        Calendar calendar = Calendar.getInstance();
                        dateTime[1] = (byte)(calendar.get(Calendar.YEAR)-2000);//年
                        dateTime[2] = (byte)(calendar.get(Calendar.MONTH)+1);//月
                        dateTime[3] = (byte)calendar.get(Calendar.DAY_OF_MONTH);//日
                        dateTime[4] = (byte)calendar.get(Calendar.HOUR_OF_DAY);//小时
                        dateTime[5] = (byte)calendar.get(Calendar.MINUTE);//分钟
                        dateTime[6] = (byte)calendar.get(Calendar.SECOND);//秒
                        dateTime[7] = 'E';
                        dateTime[8] = 'F';
                        try {
                            if(tcpClient.IsLinked()){
                                tcpClient.send(dateTime);
                            }
                            else { Looper.prepare();Toast.makeText(MainActivity.this, "TCP服务未连接!", Toast.LENGTH_SHORT).show();Looper.loop();}
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

        buttonGetTimeAndAlarmNet=(Button)findViewById(R.id.button_getTimeAndAlarmNET);
        buttonGetTimeAndAlarmNet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exec.execute(new Runnable() {
                    @Override
                    public void run() {
                        byte getDate[]=new byte[3];
                        getDate[0]='T';getDate[1]='E';getDate[2]='F';
                        try {
                            if(tcpClient.IsLinked()){
                                tcpClient.send(getDate);
                            }
                            else { Looper.prepare();Toast.makeText(MainActivity.this, "TCP服务未连接!", Toast.LENGTH_SHORT).show();Looper.loop();}
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

        buttonGetTimeSw220VPWNET=(Button)findViewById(R.id.button_SW_PWNET);
        buttonGetTimeSw220VPWNET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SetSWInformaation(0);
            }
        });


    }

    private void SetWiFiInformaation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("请输入WiFi信息");    //设置对话框标题
        builder.setIcon(R.drawable.icon);      //设置对话框标题前的图标

        final EditText editSSID = new EditText(this); //创建EditText输入框
        editSSID.setHint("请输入WiFi的SSID");
        editSSID.setWidth(48);
        editSSID.setInputType(InputType.TYPE_CLASS_TEXT);

        final EditText editPSW = new EditText(this); //创建EditText输入框
        editPSW.setHint("请输入WiFi密码");
        editPSW.setWidth(48);
        editPSW.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);

        final CheckBox showPassword=new CheckBox(this);
        showPassword.setText("显示密码");
        showPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    editPSW.setInputType(InputType.TYPE_CLASS_TEXT);
                }else{
                    editPSW.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
            }
        });

        LinearLayout layout=new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(editSSID);
        layout.addView(editPSW);
        layout.addView(showPassword);
        builder.setView(layout);
        //增加确定和取消按钮
        builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String Ssid = editSSID.getText().toString(); //获取输入框的内容
                String Password = editPSW.getText().toString(); //获取输入框的内容
                byte[] Bssid = new byte[0];
                byte[] Bpassword = new byte[0];
                try {
                    Bssid = Ssid.getBytes("GBK");
                    Bpassword = Password.getBytes("GBK");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                byte[] WiFiDate = new byte[Bssid.length + Bpassword.length+5];
                WiFiDate[0]='W';WiFiDate[1]= (byte) Bssid.length;WiFiDate[2+Bssid.length]= (byte) Bpassword.length;WiFiDate[WiFiDate.length-2]='E';WiFiDate[WiFiDate.length-1]='F';
                for (int i = 0; i < Bssid.length; i++) {
                    WiFiDate[2+i]=Bssid[i];
                }
                for(int i=0;i<Bpassword.length;i++){
                    WiFiDate[3+i+Bssid.length]=Bpassword[i];
                }
                if (outputStream != null) {
                    try {
                        outputStream.write(WiFiDate);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }else
                    Toast.makeText(MainActivity.this, "当前未连接任何设备!", Toast.LENGTH_SHORT).show();
                dialog.dismiss(); //退出对话框
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); //退出对话框
            }
        });
        builder.setCancelable(true);                 //设置按钮是否可以按返回键取消,false则不可以取消
        final AlertDialog dialog = builder.create();  //创建对话框
        dialog.setCanceledOnTouchOutside(false);      //设置弹出框失去焦点是否隐藏,即点击屏蔽其它地方是否隐藏
        dialog.show(); //显示对话框，这里必须要先调show()方法，后面的getButton才有效
    }

    private void SetSWInformaation(final int fromwhere) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.icon);      //设置对话框标题前的图标

        final LinearLayout layout=new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final TextView textView=new TextView(this);
        textView.setText("当前自动模式");

        final CheckBox OnoFF=new CheckBox(this);
        OnoFF.setText("打开220V电源");
        OnoFF.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    textView.setText("开启");
                }else{
                    textView.setText("关闭");
                }
            }
        });
        final CheckBox AutoHand=new CheckBox(this);
        AutoHand.setText("自动模式/手动模式");
        AutoHand.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    textView.setText("当前启用自动模式");    //设置对话框标题
                    layout.removeView(OnoFF);
                }else{
                    textView.setText("当前启用手动模式");    //设置对话框标题
                    layout.addView(OnoFF);
                }
            }
        });
        AutoHand.setChecked(true);
        layout.addView(AutoHand);
        builder.setView(layout);
        //增加确定和取消按钮
        builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final byte[] DATE = new byte[5];
                DATE[0]='P';DATE[1]=1;DATE[3]='E';DATE[4]='F';
                if(AutoHand.isChecked())DATE[2]=0;
                else if(OnoFF.isChecked())DATE[2]=1;
                else DATE[2]=2;
                if(fromwhere==1) {
                    if (outputStream != null) {
                        try {
                            outputStream.write(DATE);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }else
                        Toast.makeText(MainActivity.this, "当前未连接任何设备!", Toast.LENGTH_SHORT).show();
                }else if(fromwhere==0){
                    exec.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                if(tcpClient.IsLinked()){
                                    tcpClient.send(DATE);
                                }
                                else { Looper.prepare();Toast.makeText(MainActivity.this, "TCP服务未连接!", Toast.LENGTH_SHORT).show();Looper.loop();}
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
                dialog.dismiss(); //退出对话框
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); //退出对话框
            }
        });
        builder.setCancelable(true);                 //设置按钮是否可以按返回键取消,false则不可以取消
        final AlertDialog dialog = builder.create();  //创建对话框
        dialog.setCanceledOnTouchOutside(false);      //设置弹出框失去焦点是否隐藏,即点击屏蔽其它地方是否隐藏
        dialog.show(); //显示对话框，这里必须要先调show()方法，后面的getButton才有效
    }
    private int getPort(String msg){
        if (msg.equals("")){
            msg = "5050";//默认TCP连接端口
        }
        return Integer.parseInt(msg);
    }
    private String getIP(String msg){
        if (msg.equals("")){
            msg = IP_initial;
        }
        return msg;
    }

    /** 校验Ip地址是否合法
     * @param addr
     * @return
     */
    public static boolean isIpValid(String addr)
    {
        String[] ipStr = new String[4];
        int[] ipb = new int[4];
        StringTokenizer tokenizer = new StringTokenizer(addr, ".");
        int len = tokenizer.countTokens();
        if(addr.equals(IP_initial)) { return true; }
        if (len != 4)
        {
            return false;
        }
        try
        {
            int i = 0;
            while (tokenizer.hasMoreTokens())
            {
                ipStr[i] = tokenizer.nextToken();
                ipb[i] = (new Integer(ipStr[i])).intValue();

                if (ipb[i] < 0 || ipb[i] > 255)
                {
                    return false;
                }
                i++;
            }
            if (ipb[0] > 0)
            {
                return true;
            }
        }
        catch (Exception e)
        {

        }
        return false;
    }
    /**
     * 获得已经配对的蓝牙设备
     */
    private void getPairingBluetoothDevice() {
        //获得已经配对的设备
        Set<BluetoothDevice> deviceSet = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : deviceSet){
            arrayList.add(device.getName()+":"+device.getAddress());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (bluetoothSocket != null)
                        bluetoothSocket.close();

                    if (inputStream != null)
                        inputStream.close();

                    if (outputStream != null)
                        outputStream.close();

                    if (acceptThread.isInterrupted() == false){
                        acceptThread.stopThread();
                    }
                    tcpClient.closeSelf();
                }catch (IOException e){
                    e.printStackTrace();
                }
            }
        }).start();

        //注销广播
        unregisterReceiver(mRceiver);
        //关闭蓝牙
        //bluetoothAdapter.disable();
    }
    /**
     * 处理其他线程发来的消息
     */
    class MyHandler extends Handler {
        private String date_bufferBT = " ";
        private String date_bufferTCP = " ";
        // pw.write( msg.getBytes("GBK"));
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                //MESSAGE_DATA为0x01，表示蓝牙接收的数据。该消息附带接收到的数据,用于更新UI显示
                case MainActivity.MESSAGE_DATA: {
                    final String data = msg.obj.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "收到一个蓝牙消息!");
                            date_bufferBT=date_bufferBT+data;
                            try {
                                while(processDate()){

                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    break;
                }//end of case
                //0x02，表示TCP接收的数据。该消息附带接收到的数据,用于更新UI显示
                case 2 :{
                    final String data = msg.obj.toString();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG, "收到一个TCP消息!");
                            date_bufferTCP=date_bufferTCP+data;
                            textViewTcpRec.setText("");
                            textViewTcpRec.append(data);
                        }
                    });
                }

                default:break;
            }
        }
        //实现不同段的截取
        public boolean processDate()throws Exception{
                for (int i = 1; i <= date_bufferBT.length(); i++)
                {
                    if (date_bufferBT.substring(0, i).contains("\r\n"))
                    {
                        arrayList.add(date_bufferBT.substring(0, i - 1));
                        arrayAdapter.notifyDataSetChanged(); //通知ListView适配器 数据已经发生改变
                        date_bufferBT=date_bufferBT.substring(i);
                        return true;
                    }
                }
                return false;
        }
    }

    // 服务端接收信息线程
    private class AcceptThread extends Thread {

        private Boolean isStop = false;
        private byte[] buf = new byte[128];
        private int len=0;

        public AcceptThread() {
        }

        public void stopThread(){
            isStop = true;
        }

        public void run() {
            while (!isStop){
                while (inputStream != null)
                    try {
                        len = inputStream.read(buf);
                        Message msg = Message.obtain();
                        msg.what = MainActivity.MESSAGE_DATA;
                        Bundle bundle = new Bundle();
                        msg.obj = new String(buf, 0, len);
                        myHandler.sendMessage(msg);
                        //Thread.sleep(1000);
                    } catch (IOException e) {
                        e.printStackTrace();
                    } //catch (InterruptedException e) {
                       // e.printStackTrace();
                   // }

            }

        }//end of while run()
    }// end of private class AcceptThread extends Thread {
    /**
     * 解决：无法发现蓝牙设备的问题
     *
     * 对于发现新设备这个功能, 还需另外两个权限(Android M 以上版本需要显式获取授权,附授权代码):
     */
    private final int ACCESS_LOCATION=1;
    @SuppressLint("WrongConstant")
    private void getPermission() {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            int permissionCheck = 0;
            permissionCheck = this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION);
            permissionCheck += this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION);

            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                //未获得权限
                this.requestPermissions( // 请求授权
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION},
                        ACCESS_LOCATION);// 自定义常量,任意整型
            }
        }
    }

    /**
     * 请求权限的结果回调。每次调用 requestpermissions（string[]，int）时都会调用此方法。
     * @param requestCode 传入的请求代码
     * @param permissions 传入permissions的要求
     * @param grantResults 相应权限的授予结果:PERMISSION_GRANTED 或 PERMISSION_DENIED
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case ACCESS_LOCATION:
                if (hasAllPermissionGranted(grantResults)) {
                    Log.i(TAG, "onRequestPermissionsResult: 用户允许权限");
                } else {
                    Log.i(TAG, "onRequestPermissionsResult: 拒绝搜索设备权限");
                }
                break;
        }
    }

    private boolean hasAllPermissionGranted(int[] grantResults) {
        for (int grantResult : grantResults) {
            if (grantResult == PackageManager.PERMISSION_DENIED) {
                return false;
            }
        }
        return true;
    }
}

